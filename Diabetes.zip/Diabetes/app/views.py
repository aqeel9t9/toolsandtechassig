from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib


# get current directory path 
import os
c_path = os.path.abspath(os.getcwd())

# View
@api_view(['POST'])
def diabetes_detect(request):
    if request.method=='POST':
        age = float(request.data['age'])
        gender = request.data['gender']
        bmi = float(request.data['bmi'])  # Include BMI in the user input
        HbA1c_level = float(request.data['hba1c'])
        blood_glucose_level = float(request.data['glucose'])
        hypertension = int(request.data['hypertension'])
        heart_disease = int(request.data['heart'])
        if age and  gender and bmi and HbA1c_level and blood_glucose_level and hypertension != '' and heart_disease !='':
            # Load the trained model
            model_path = c_path + '/trained_model.pkl'
            loaded_model = joblib.load(model_path)


            # Preprocess the user input for prediction
            data_for_prediction = pd.DataFrame({'age': [age],
                                                'gender': [gender],
                                                'HbA1c_level': [HbA1c_level],
                                                'blood_glucose_level': [blood_glucose_level],
                                                'hypertension': [hypertension],
                                                'heart_disease': [heart_disease],
                                                'bmi': [bmi],  # Include BMI in the DataFrame
                                                })

            # Assuming you have encoded 'gender' during training, you may need to encode it here as well
            data_for_prediction['gender'] = data_for_prediction['gender'].map({'Female': 0, 'Male': 1, 'Other': 2})




            scaler = StandardScaler()
            scaled_features = scaler.fit_transform(data_for_prediction[['age', 'HbA1c_level', 'blood_glucose_level']])
            data_for_prediction.drop(['age', 'HbA1c_level', 'blood_glucose_level'], axis=1, inplace=True)
            scaled_features_df = pd.DataFrame(scaled_features, columns=['age', 'HbA1c_level', 'blood_glucose_level'])
            final_data_for_prediction = pd.concat([scaled_features_df, data_for_prediction], axis=1)

            # Predict using the loaded model
            prediction = loaded_model.predict(final_data_for_prediction)[0]

            if prediction == 1:
                result = "Patient has Diabetes"
            else:
                result = "Patient does not have Diabetes"
            # Print the prediction
            print("Predicted diabetes status: ", prediction)

            # If you want to use the probabilities instead of binary predictions, use the following:
            probabilities = loaded_model.predict_proba(final_data_for_prediction)[0]
            print("Probabilities: ", probabilities)


            return Response({'status':result,'probabilities':probabilities},status=status.HTTP_201_CREATED)
        else:
            return Response({'error':"All Fields are Required!"},status=status.HTTP_400_BAD_REQUEST)
        